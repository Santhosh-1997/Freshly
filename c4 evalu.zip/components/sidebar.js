function sidebar() {


    // return your html component here
    //Make sure to give input search box id as ""
    return `   <h2>menu</h2>
    <h2>login</h2>
    <h2>sign Up</h2>
    <input type="text" placeholder="Search" id="searchbar">`
}
export default sidebar